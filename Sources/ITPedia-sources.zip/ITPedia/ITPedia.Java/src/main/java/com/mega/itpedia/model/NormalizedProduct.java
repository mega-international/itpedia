package com.mega.itpedia.model;

import org.codehaus.jackson.annotate.JsonProperty;
import org.codehaus.jackson.map.annotate.JsonSerialize;
import org.codehaus.jackson.map.annotate.JsonSerialize.Inclusion;

@JsonSerialize(include = Inclusion.NON_EMPTY)
public class NormalizedProduct {
  @JsonProperty("cModel_ID")
  public String id;

  @JsonProperty("releaseDate")
  public String releaseDate;

  @JsonProperty("endOfSupport")
  public String endOfSupport;

  @JsonProperty("endOfExtendedSupport")
  public String endOfExtendedSupport;

  @JsonProperty("category")
  public String category;

  @JsonProperty("catalogItemName")
  public String catalogItemName;

  @JsonProperty("manufacturer")
  public String manufacturerName;

  @JsonProperty("rawManufacturerPartNo")
  public String mFGPartNo;

  @JsonProperty("startOfLife")
  public String startOfLife;

  @JsonProperty("endOfSale")
  public String endOfSale;

  @JsonProperty("endOfLife")
  public String endOfLife;

  //  @JsonProperty("normalized_PartNumber")
  //  public String partNumber;

  @JsonProperty("version")
  public String version;

  @JsonProperty("edition")
  public String edition;

  @JsonProperty("defaultLicenseType")
  public String defaultLicenseType;
  @JsonProperty("operatingSystem")
  public String operatingSystem;

  @JsonProperty("itemsPerProduct")
  public String itemsPerProduct;

  @JsonProperty("priceDate")
  public String priceDate;

  //  @JsonProperty("normalized_UnitCost")
  //  public String unitCost;

  public String getId() {
    return this.id;
  }

  public void setId(final String _id) {
    this.id = _id;
  }

  public String getReleaseDate() {
    return this.releaseDate;
  }

  public void setReleaseDate(final String _releaseDate) {
    this.releaseDate = _releaseDate;
  }

  public String getEndOfSupport() {
    return this.endOfSupport;
  }

  public void setEndOfSupport(final String _endOfSupport) {
    this.endOfSupport = _endOfSupport;
  }

  public String getEndOfExtendedSupport() {
    return this.endOfExtendedSupport;
  }

  public void setEndOfExtendedSupport(final String _endOfExtendedSupport) {
    this.endOfExtendedSupport = _endOfExtendedSupport;
  }

  public String getCategory() {
    return this.category;
  }

  public void setCategory(final String _category) {
    this.category = _category;
  }

  public String getCatalogItemName() {
    return this.catalogItemName;
  }

  public void setCatalogItemName(final String _catalogItemName) {
    this.catalogItemName = _catalogItemName;
  }

  public String getManufacturerName() {
    return this.manufacturerName;
  }

  public void setManufacturerName(final String _manufacturerName) {
    this.manufacturerName = _manufacturerName;
  }

  public String getmFGPartNo() {
    return this.mFGPartNo;
  }

  public void setmFGPartNo(final String _mFGPartNo) {
    this.mFGPartNo = _mFGPartNo;
  }

  public String getStartOfLife() {
    return this.startOfLife;
  }

  public void setStartOfLife(final String _startOfLife) {
    this.startOfLife = _startOfLife;
  }

  public String getEndOfSale() {
    return this.endOfSale;
  }

  public void setEndOfSale(final String _endOfSale) {
    this.endOfSale = _endOfSale;
  }

  public String getEndOfLife() {
    return this.endOfLife;
  }

  public void setEndOfLife(final String _endOfLife) {
    this.endOfLife = _endOfLife;
  }

  public String getVersion() {
    return this.version;
  }

  public void setVersion(final String _version) {
    this.version = _version;
  }

  public String getEdition() {
    return this.edition;
  }

  public void setEdition(final String _edition) {
    this.edition = _edition;
  }

  public String getDefaultLicenseType() {
    return this.defaultLicenseType;
  }

  public void setDefaultLicenseType(final String _defaultLicenseType) {
    this.defaultLicenseType = _defaultLicenseType;
  }

  public String getOperatingSystem() {
    return this.operatingSystem;
  }

  public void setOperatingSystem(final String _operatingSystem) {
    this.operatingSystem = _operatingSystem;
  }

  public String getItemsPerProduct() {
    return this.itemsPerProduct;
  }

  public void setItemsPerProduct(final String _itemsPerProduct) {
    this.itemsPerProduct = _itemsPerProduct;
  }

  public String getPriceDate() {
    return this.priceDate;
  }

  public void setPriceDate(final String _priceDate) {
    this.priceDate = _priceDate;
  }

}
