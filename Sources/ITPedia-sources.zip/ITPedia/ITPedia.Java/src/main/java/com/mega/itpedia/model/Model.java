package com.mega.itpedia.model;

import org.codehaus.jackson.annotate.JsonProperty;

public class Model {

  @JsonProperty("cModel_ID")
  String id;
  @JsonProperty("modelName")
  String name;

  @JsonProperty("mfgName")
  String mfgName;

  @JsonProperty("prodName")
  String prodName;

  @JsonProperty("version")
  String version;

  @JsonProperty("platform")
  String platform;

  @JsonProperty("discoveryModel_ID")
  String discoveryModel_ID;

  @JsonProperty("isVerified")
  String isVerified;

  public String getMfgName() {
    return this.mfgName;
  }

  public void setMfgName(final String mfgName) {
    this.mfgName = mfgName;
  }

  public String getProdName() {
    return this.prodName;
  }

  public void setProdName(final String prodName) {
    this.prodName = prodName;
  }

  public String getVersion() {
    return this.version;
  }

  public void setVersion(final String version) {
    this.version = version;
  }

  public String getPlatform() {
    return this.platform;
  }

  public void setPlatform(final String platform) {
    this.platform = platform;
  }

  public String getDiscoveryModel_ID() {
    return this.discoveryModel_ID;
  }

  public void setDiscoveryModel_ID(final String discoveryModel_ID) {
    this.discoveryModel_ID = discoveryModel_ID;
  }

  public String getId() {
    return this.id;
  }

  public void setId(final String id) {
    this.id = id;
  }

  public String getIsVerified() {
    return this.isVerified;
  }

  public void setIsVerified(final String isVerified) {
    this.isVerified = isVerified;
  }

  public String getName() {
    return this.name;
  }

  public void setName(final String name) {
    this.name = name;
  }

}
