package com.mega.itpedia.model;

import org.codehaus.jackson.annotate.JsonProperty;

public class Manufacturer {

    @JsonProperty("cMfg_ID")
    public int id;


    @JsonProperty("mfgName")
    String  name;


    public int getId() {
        return id;
    }


    public void setId(int id) {
        this.id = id;
    }


    public String getName() {
        return name;
    }


    public void setName(String name) {
        this.name = name;
    }






}
