package com.mega.itpedia;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import org.codehaus.jackson.map.DeserializationConfig;
import org.codehaus.jackson.map.ObjectMapper;
import org.json.JSONArray;

import com.mega.itpedia.connexion.Token;
import com.mega.itpedia.model.Manufacturer;
import com.mega.itpedia.model.Model;
import com.mega.itpedia.model.Product;
import com.mega.itpedia.model.PublicManufacturers;
import com.mega.itpedia.model.PublicModels;
import com.mega.itpedia.model.PublicProducts;
import com.mega.modeling.api.MegaRoot;

public class ITPedia {
	Token currentToken = null;

	public Token getCurrentToken() {
		return this.currentToken;
	}

	public void setCurrentToken(final Token currentToken) {
		this.currentToken = currentToken;
	}

	/** Fetch Manufacturer List */
	String sEndPointPublicManufacturers = "v2/PublicManufacturers?$filter=startswith(mfgName,'%20KEY%20')";

	/** Fetch Products By Manufacturer ID */
	private String sEndPointPublicProduct = "v2/PublicProducts/?$filter=startswith(prodName,'%20KEY%20')%20and%20cMfg_ID%20eq%20";

	/** Fetch Models By Product ID */
	private String sEndPointPublicModels = "v2/PublicModels/?$filter=cProduct_ID%20eq%20";
	
	public String getManufacturersList(final MegaRoot root, final String keyword) {
		String result = "";
		try {
			this.currentToken = new Token(root);
			String sUrl = this.currentToken.getItPediaURL().concat(this.sEndPointPublicManufacturers)
					.replace("%20KEY%20", keyword);
			String strResult = this.currentToken.doGet(sUrl);
			if (!strResult.isEmpty()) {
				ObjectMapper oMapper = new ObjectMapper();
				oMapper.configure(DeserializationConfig.Feature.FAIL_ON_UNKNOWN_PROPERTIES, false);
				PublicManufacturers publicManufacturers = oMapper.readValue(strResult, PublicManufacturers.class);

				JSONArray array = new JSONArray();
				for (Manufacturer m : publicManufacturers.getManufacturers()) {
					ObjectMapper oMapper2 = new ObjectMapper();
					String jString = oMapper2.writeValueAsString(m);
					array.put(jString);
				}
				result = array.toString();
			}
		} catch (Exception ex) {
			ex.printStackTrace();
		}
		return result.replace("\\", "").replace("\",\"", ",").replace("[\"{", "[{").replace("}\"]", "}]");
	}

	public String getProductList(final MegaRoot root, final int manufacturerID, final String keyword) {
		String result = "";
		try {
			this.currentToken = new Token(root);
			String sUrl = this.currentToken.getItPediaURL().concat(this.sEndPointPublicProduct + manufacturerID)
					.replace("%20KEY%20", keyword);
			String strResult = this.currentToken.doGet(sUrl);
			if (!strResult.isEmpty()) {
				ObjectMapper oMapper = new ObjectMapper();
				oMapper.configure(DeserializationConfig.Feature.FAIL_ON_UNKNOWN_PROPERTIES, false);
				PublicProducts publicProducts = oMapper.readValue(strResult, PublicProducts.class);
				JSONArray array = new JSONArray();
				for (Product p : publicProducts.getproducts()) {
					ObjectMapper oMapper2 = new ObjectMapper();
					String jString = oMapper2.writeValueAsString(p);
					array.put(jString);
				}
				result = array.toString();
			}
		} catch (Exception ex) {
			ex.printStackTrace();
		}
		return result.replace("\\", "").replace("\",\"", ",").replace("[\"{", "[{").replace("}\"]", "}]");
	}

	public String getModelList(final MegaRoot root, final int productId) {
		String result = "";
		try {
			List<Model> listModels = new ArrayList<>();
			this.currentToken = new Token(root);
			String sUrl = this.currentToken.getItPediaURL().concat(this.sEndPointPublicModels + productId);
			PublicModels pListModels = new PublicModels();
			do {
				String strResult = this.currentToken.doGet(sUrl);
				if (!strResult.isEmpty()) {
					ObjectMapper oMapper = new ObjectMapper();
					oMapper.configure(DeserializationConfig.Feature.FAIL_ON_UNKNOWN_PROPERTIES, false);
					pListModels = oMapper.readValue(strResult, PublicModels.class);
					listModels.addAll(pListModels.getModels());
					Model max = listModels.stream().max(Comparator.comparing(Model::getId)).orElseThrow(null);
					sUrl = this.currentToken.getItPediaURL().concat(
							this.sEndPointPublicModels + productId + "%20and%20" + "cModel_ID%20ge%20" + max.getId());
				} 
			}while (pListModels.getNextLink() != null);
				
			JSONArray array = new JSONArray();
			for (Model m : listModels) {
				ObjectMapper oMapper = new ObjectMapper();
				String jString = oMapper.writeValueAsString(m);
				array.put(jString);
			}
			result = array.toString();

		} catch (Exception e) {
			e.printStackTrace();
		}
		return result.replace("\\", "").replace("}\",\"{", "},{").replace("[\"{", "[{").replace("}\"]", "}]");
	}

}
