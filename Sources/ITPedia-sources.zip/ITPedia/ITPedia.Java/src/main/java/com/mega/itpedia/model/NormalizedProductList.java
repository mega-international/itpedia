package com.mega.itpedia.model;

import java.util.List;

import org.codehaus.jackson.annotate.JsonProperty;
import org.codehaus.jackson.map.annotate.JsonSerialize;
import org.codehaus.jackson.map.annotate.JsonSerialize.Inclusion;

@JsonSerialize(include = Inclusion.NON_NULL)
public class NormalizedProductList {
  @JsonProperty("@odata.nextLink")
  String                  nextLink;
  @JsonProperty("value")
  List<NormalizedProduct> items;

  public String getNextLink() {
    return this.nextLink;
  }

  public void setNextLink(final String nextLink) {
    this.nextLink = nextLink;
  }

  public List<NormalizedProduct> getItems() {
    return this.items;
  }

  public void setItems(final List<NormalizedProduct> items) {
    this.items = items;
  }

}
