package com.mega.itpedia;

import com.mega.modeling.api.MegaCOMObject;
import com.mega.modeling.api.MegaObject;
import com.mega.modeling.api.MegaRoot;



public class ScheduledImportJob {
    public boolean RunScheduledJob(final MegaObject mgobjSystemJob, final MegaCOMObject objJobResult) throws Exception {
        MegaRoot mgRoot = mgobjSystemJob.getRoot();
        boolean bResult = true;

        ImportNormalizedProduct ImportNormalizedProduct = new ImportNormalizedProduct();
        ImportNormalizedProduct.update(mgRoot);
        // ImportCatalog catalog = null;
        // try {
        //   eracentToken = new Token(mgRoot);
        //   catalog = new ImportCatalog();
        //   catalog.runImport(eracentToken, false, mgobjSystemJob.getRoot());
        //   strDiagMessage = "Softwares technologies import operation succeed. " + "\n" + "Total number of objects created : " + catalog.getNumberOfCreatedTechnolgy() + "." + "\n" + "Total number of objects updated : " + catalog.getNumberofTechnologyUpdated() + "." + "\n" + "Total number of objects not found in IT-Pedia/My Products : " + catalog.getNumberofNotfoundTech() + "." + "\n";
    
        // } catch (Exception e) {
        //   bResult = false;
        //   MegaException me = new MegaException(strErrorMessage, Mode.APPLICATIF);
        //   me.setStackTrace(e.getStackTrace());
        //   MegaErrorManager errorManager = MegaErrorManager.getErrorManager(mgRoot);
        //   errorManager.exceptionReport(me);
        // }
        // objJobResult.invokePropertyPut("DiagMessage", strDiagMessage + bResult);
        // objJobResult.invokePropertyPut("ErrorMessage", strErrorMessage);
        // objJobResult.invokePropertyPut("RemoveTrigger", bRemoveTrigger);
        return bResult;
      }
}
