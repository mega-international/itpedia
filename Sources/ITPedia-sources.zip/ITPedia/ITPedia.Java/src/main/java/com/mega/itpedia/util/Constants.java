package com.mega.itpedia.util;

import java.text.SimpleDateFormat;
import java.text.ParseException;
import java.text.DateFormat;
import java.util.Date;

public interface Constants {
  public static String ERACENT_KO_STATUT = "KO";
  public static String MA_COMPANY_STANDARD = "~)4UwO20HID0H[Company Standard]";
  public static String MC_VENDOR = "~QrUiM9B5iCN0[Org-Unit]";
  public static String MC_LIBRARY = "~Q4YSV5O8za40[Library]";
  public static String MC_TYPE = "~yHhHxRKym020[_Type]";
  public static String MC_SOFTWARE_TECHNOLOGY = "~FN8AHc2gITnL[Software Technology]";
  public static String MC_ADD_IN_DATA = "~juZY8ge4xO00[_Add-ins_data]";

  public static String MG_ITPEDIA = "~D8AlBOEoV5e5[IT-Pedia]";
  public static String MG_ITPEDIA_NOT_FOUND = "~o8koYZGnV14E[Not Found In IT-Pedia]";
  public static String MG_ITPEDIA_LIBRARY = "~o5igMqg)Vj8N[IT-Pedia]";

  public static String MAE_LIBRARY_PACKAGED_ELEMENT = "~XI(ov(ir7nK0[Packaged Element]";
  public static String MAE_TYPE_ST = "~e3jEF74gILuJ[_Type]";
  public static String MAE_SUB_TYPE = "~N4OHGt5goe40[Set _Type]";

  public static String Q_GET_IMPORTED_VENDOR = "~Doh13WWoVrZM[IT-Pedia - Get Vendor Imported From ITpedia]";
  public static String Q_GET_Eracent_SOFTWARE_TECHNOLOGIES = "~dVBrLkHlVTO2[ITPM - ITPEDIA - Get All Technologues imported from IT-Pedia]";

  public static String MA_NAME = "~210000000900[Name]";
  public static String MA_SHORT_NAME = "~Z20000000D60[Short Name]";
  public static String MA_NOT_FOUND = "~brLEigpqVj7F[Not Found in IT-Pedia My Products]";
  public static String MA_CATALOG_ITEM_NAME = "~0VBruaDlVTW0[IT-Pedia Catelog Item Name]";
  public static String MA_DEFAULT_LICENCE_TYPE = "~rTBrnqDlVvx0[IT-Pedia Default Licence Type]";
  public static String MA_EDITION = "~hVBrwrDlVj(0[IT-Pedia Edition]";
  public static String MA_IDENTIFIER = "~1TBrpRDlV5T0[IT-Pedia Identifier]";
  public static String MA_ITEMS_PER_PRODUCT = "~nVBrXuDlVX41[IT-Pedia Items Per Product]";
  public static String MA_MGF_PART_NUMBER = "~yUBrelDlV5b0[IT-Pedia MGF Part Number]";
  public static String MA_OPERATING_SYSTEM = "~aUBr1uDlVj11[IT-Pedia Operating System]";
  public static String MA_PART_NUMBER = "~IVBrfpDlVHs0[IT-Pedia Part Number]";
  public static String MA_UNIT_COST = "~RSBrPmDlVvd0[IT-Pedia Unit Csot]";
  public static String MA_VERSION = "~YSBrBqDlV5v0[IT-Pedia Version]";

  public static String MA_END_OF_SUPPORT = "~2MQez8wrIX23[End of Support]";
  public static String MA_ENF_OF_SUPPORT_NOTES = "~FEtSBV7sV9jN[IT-Pedia End of Support Notes]";

  public static String MA_END_OF_EXTENDED_SUPPORT = "~vNQeZ9wrIb73[End of Extended Support]";
  public static String MA_END_OF_EXTENDED_SUPPORT_NOTES = "~aCtSDU7sVLgN[IT-Pedia End of Extended Support Notes]";

  public static String MA_START_OF_LIFE = "~tUBrOnDlVjj0[IT-Pedia Start Of Life]";
  public static String MA_START_OF_LIFE_NOTES = "~oFtSSP7sVPQN[IT-Pedia Start of Life notes]";

  public static String MA_END_OF_LIFE = "~MSBr7oDlVfm0[IT-Pedia End Of Life]";
  public static String MA_END_OF_LIFE_NOTES = "~XEtSxO7sVPNN[IT-Pedia End of Life notes]";

  public static String MA_END_OF_SALE = "~QTBrUoDlVTp0[IT-Pedia End Of Sale]";
  public static String MA_END_OF_SALE_NOTES = "~rFtSrG7sVDDN[IT-Pedia End of Sale notes]";

  public static String MA_PRICE_DATE = "~PTBrgmDlVjg0[IT-Pedia Price Date]";
  public static String MA_PRICE_DATE_NOTES = "~oCtSlP7sVDTN[IT-Pedia Price Date notes]";

  public static String MA_RELEASE_DATE = "~1NQepAwrI5F3[Release Date]";
  public static String MA_RELEASE_DATE_NOTES = "~8FtSXT7sVLdN[IT-Pedia Release Date Notes]";

  public static boolean isValidDate(final String inDate) {
    if (inDate == null) {
      return false;
    }
    SimpleDateFormat dateFormat = new SimpleDateFormat("y-M-d");
    try {
      dateFormat.parse(inDate.trim());
    } catch (ParseException pe) {
      return false;
    }
    return true;
  }

  public static Date convertToMegaDate(final String d) {
    DateFormat eracent = new SimpleDateFormat("y-M-d");
    Date date = null;
    try {
      date = eracent.parse(d);
    } catch (ParseException e) {
      e.printStackTrace();
    }

    return date;
  }

}
