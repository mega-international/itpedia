package com.mega.itpedia.model;
import org.codehaus.jackson.annotate.JsonProperty;
import java.util.List;



public class PublicManufacturers {

    @JsonProperty("@odata.nextLink")
    String nextLink;
    @JsonProperty("value")
    List<Manufacturer> manufacturers;

    public String getNextLink() {
        return nextLink;
    }

    public void setNextLink(String nextLink) {
        this.nextLink = nextLink;
    }

    public List<Manufacturer> getManufacturers() {
        return manufacturers;
    }

    public void setManufacturers(List<Manufacturer> manufacturers) {
        this.manufacturers = manufacturers;
    }


}