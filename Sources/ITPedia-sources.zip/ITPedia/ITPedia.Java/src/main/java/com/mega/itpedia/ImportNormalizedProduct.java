package com.mega.itpedia;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.codehaus.jackson.map.DeserializationConfig;
import org.codehaus.jackson.map.ObjectMapper;

import com.mega.itpedia.connexion.Token;
import com.mega.itpedia.model.NormalizedProduct;
import com.mega.itpedia.model.NormalizedProductList;
import com.mega.itpedia.util.Constants;
import com.mega.modeling.api.MegaCollection;
import com.mega.modeling.api.MegaObject;
import com.mega.modeling.api.MegaRoot;

public class ImportNormalizedProduct {

  private String sEndPointPublicProduct = "v2/AddMultipleModelsToMyProducts(CModelIDsArray=[%20KEY%20])";
  private String sEndPointMyProducts = "v2/MyProducts/";
  private MegaObject moITPEDIALibrary;
  int numberOfCreatedTechnolgy;
  int numberofTechnologyUpdated;
  int numberofNotfoundTech;



  public void update(final MegaRoot root) throws Exception {
    this.runImport(root, "", true);
    root.callMethod("messagebox",
        this.numberOfCreatedTechnolgy + " "
            + root.currentEnvironment().resources()
                .name("~v7kqrVzfW9KC[IT-Pedia Software technologies created]", "GUILocalName")
            + " \n" + this.numberofTechnologyUpdated + " "
            + root.currentEnvironment().resources()
                .name("~U7kqnYzfWfMC[IT-Pedia - software technologies updated]", "GUILocalName")
            + "  \n " + this.numberofNotfoundTech + " "
            + root.currentEnvironment().resources().name("~F5kqwZzfW9PC[IT-Pedia - software technologies not found]",
                "GUILocalName"),
        root.currentEnvironment().resources().name("~24kqMbzfWXUC[IT-Pedia Importation Results]", "GUILocalName"), 0);

  }

  public String runImport(final MegaRoot root, final String models, final boolean isUpdate) {
    this.numberOfCreatedTechnolgy = 0;
    this.numberofTechnologyUpdated = 0;
    this.numberofNotfoundTech = 0;
    List<NormalizedProduct> products = new ArrayList<NormalizedProduct>();
    //do res
    try {
      Token currentToken = new Token(root);
      String sUrl = "";

      if (isUpdate) {
        sUrl = currentToken.getItPediaURL().concat(this.sEndPointMyProducts);
        String strResult = "";
        strResult = currentToken.doGet(sUrl);
        NormalizedProductList values = new NormalizedProductList();
        ObjectMapper oMapper = new ObjectMapper();
        oMapper.configure(DeserializationConfig.Feature.FAIL_ON_UNKNOWN_PROPERTIES, false);
        if (!strResult.isEmpty()) {
          values = oMapper.readValue(strResult, NormalizedProductList.class);
          products.addAll(values.getItems());
        }

      } else {
        List<String> request = ImportNormalizedProduct.splitModels(models);

        for (String modelsItem : request) {
          String strResult = "";
          sUrl = currentToken.getItPediaURL().concat(this.sEndPointPublicProduct).replace("%20KEY%20", modelsItem)
              .replace("[", "%5B").replace("]", "%5D").replace("=", "%3D");
          strResult = currentToken.doPost(sUrl);
          NormalizedProductList values = new NormalizedProductList();
          ObjectMapper oMapper = new ObjectMapper();
          oMapper.configure(DeserializationConfig.Feature.FAIL_ON_UNKNOWN_PROPERTIES, false);
          if (!strResult.isEmpty()) {
            values = oMapper.readValue(strResult, NormalizedProductList.class);
            products.addAll(values.getItems());

          }
        }
      }

      HashMap<String, MegaObject> mapEracentTechnologies = new HashMap<String, MegaObject>();
      mapEracentTechnologies = new HashMap<String, MegaObject>();
      MegaCollection mgcolSTImportedFromEracent = root.getCollection(Constants.Q_GET_Eracent_SOFTWARE_TECHNOLOGIES);
      for (MegaObject oST : mgcolSTImportedFromEracent) {
        mapEracentTechnologies.put(oST.getProp(Constants.MA_IDENTIFIER), oST);
      }
      mgcolSTImportedFromEracent.release();

      if (products != null) {
        this.createOrUpdateSoftwareTechnologies(root, products, mapEracentTechnologies);
        if (isUpdate)
          this.updateNotFoundAttribute(products, mapEracentTechnologies);
      }
    } catch (Exception e) {
      return e.getMessage();
    }
    return "" + products.size() + "==" + this.numberOfCreatedTechnolgy;
  }

  private static List<String> splitModels(final String models) {
    List<String> requests = new ArrayList<String>();
    String toProcess = models;
    double db = (double) models.length() / 90;
    while (db > 1) {
      int lastIndex = toProcess.lastIndexOf(",", 90);
      requests.add(toProcess.substring(0, lastIndex));
      toProcess = toProcess.substring(lastIndex + 1);
      db = (double) toProcess.length() / 90;
    }
    if (!toProcess.isEmpty()) {
      requests.add(toProcess);
    }
    return requests;
  }

  private void createOrUpdateSoftwareTechnologies(final MegaRoot root, final List<NormalizedProduct> products,
      final HashMap<String, MegaObject> mapEracentTechnologies) {
    MegaCollection mgColSoftwareTechnology = root.getCollection(Constants.MC_SOFTWARE_TECHNOLOGY);
    MegaObject softwareTechnologyToAddOrUpdate;
    for (NormalizedProduct product : products) {

      if (mapEracentTechnologies.get(product.getId()) == null) {
        softwareTechnologyToAddOrUpdate = mgColSoftwareTechnology.create(product.getCatalogItemName());
        softwareTechnologyToAddOrUpdate.setProp(Constants.MA_IDENTIFIER, product.getId());
        softwareTechnologyToAddOrUpdate.setProp(Constants.MA_NOT_FOUND, false, "internal");
        this.addtoItpediaLibrary(softwareTechnologyToAddOrUpdate);
        if (product.getCategory() != null)
          this.addTehcnologieType(softwareTechnologyToAddOrUpdate, root.getObjectFromID(Constants.MG_ITPEDIA),
              product.getCategory());
        this.numberOfCreatedTechnolgy++;
      } else {
        softwareTechnologyToAddOrUpdate = mapEracentTechnologies.get(product.getId());
        softwareTechnologyToAddOrUpdate.setProp(Constants.MA_NOT_FOUND, false, "internal");
        this.numberofTechnologyUpdated++;
      }
      this.addVendor(softwareTechnologyToAddOrUpdate, product.getManufacturerName());
      this.setMegaProperty(softwareTechnologyToAddOrUpdate, product);
    }

  }

  private void addTehcnologieType(final MegaObject oSoftwareTechnology, final MegaObject oParentType,
      final String sCategory) {
    String[] sTypes = sCategory.split("\\\\");
    String sTypeName = sTypes[0];
    boolean isLast = sTypes.length == 1 ? true : false;
    String sNewCategory = "";
    if (!isLast) {
      sNewCategory = sCategory.substring(sCategory.indexOf("\\") + 1);

    }
    MegaCollection mcSubTypes = oParentType.getCollection(Constants.MAE_SUB_TYPE);
    boolean isFound = false;
    for (MegaObject oSubType : mcSubTypes) {
      if (oSubType.getProp("~fL9VksNzVnPF[IT-Pedia Name]").equals(sTypeName)) {

        isFound = true;
        if (isLast) {
          oSoftwareTechnology.getCollection(Constants.MAE_TYPE_ST).add(oSubType);

        } else {
          this.addTehcnologieType(oSoftwareTechnology, oSubType, sNewCategory);
        }
        oSubType.release();
        return;
      }
      oSubType.release();
    }
    if (!isFound) {
      MegaObject oType = this.createType(oParentType, sTypeName);
      if (isLast) {
        oSoftwareTechnology.getCollection(Constants.MAE_TYPE_ST).add(oType);
      } else {
        this.addTehcnologieType(oSoftwareTechnology, oType, sNewCategory);
      }
    }
    mcSubTypes.release();
  }

  MegaObject createType(final MegaObject oParentType, final String sTypeName) {
    MegaObject oType = oParentType.getCollection(Constants.MAE_SUB_TYPE).create();
    oType.setProp("~fL9VksNzVnPF[IT-Pedia Name]", sTypeName);
    this.RenameCategory(oType, sTypeName);
    return oType;
  }

  public void RenameCategory(final MegaObject oCategory, final String sName) {
    this.RenameCategory(oCategory, sName, 0);
  }

  public void RenameCategory(final MegaObject oCategory, final String sName, final int iIncrement) {
    int iInc = iIncrement;
    if (iInc > 10) {
      return;
    }
    try {
      if (iInc == 0) {
        oCategory.setProp("~Z20000000D60[Short Name]", sName);
      } else {
        oCategory.setProp("~Z20000000D60[Short Name]", sName + " - " + iInc);
      }
    } catch (Exception ex) {
      iInc++;
      this.RenameCategory(oCategory, sName, iInc);
    }
  }

  private void addVendor(final MegaObject softwareTechnologyToAddOrUpdate, final String manufacturerName) {

    MegaObject oVendor = this.getVendor(softwareTechnologyToAddOrUpdate.getRoot(), manufacturerName);
    if (null == oVendor) {
      oVendor = softwareTechnologyToAddOrUpdate.getCollection("~3L8Asc2gIPsL[Vendor]").create(manufacturerName);
      oVendor.setProp(Constants.MA_SHORT_NAME, manufacturerName);
      oVendor.setProp("~mW6W42O3pG00[Internal/External]", "X");
      oVendor.setProp("~XpFbeKfOn400[Org-Unit-Type]", "V");

    }
    softwareTechnologyToAddOrUpdate.getCollection("~3L8Asc2gIPsL[Vendor]").add(oVendor);

  }

  private MegaObject getVendor(final MegaRoot root, final String manufacturerName) {

    MegaCollection vendorsImportedFromITPedia = root.getCollection(Constants.MC_VENDOR);

    for (MegaObject vendor : vendorsImportedFromITPedia) {
      if (vendor.getProp(Constants.MA_SHORT_NAME).equals(manufacturerName)) {
        return vendor;
      }
    }
    vendorsImportedFromITPedia.release();
    return null;

  }

  private void addtoItpediaLibrary(final MegaObject softwareTechnologyToAddOrUpdate) {
    MegaCollection mColPackagedElements = this.getITPediaLibrary(softwareTechnologyToAddOrUpdate.getRoot())
        .getCollection(Constants.MAE_LIBRARY_PACKAGED_ELEMENT);
    mColPackagedElements.add(softwareTechnologyToAddOrUpdate);
    mColPackagedElements.release();
  }

  private MegaObject getITPediaLibrary(final MegaRoot root) {
    if (this.moITPEDIALibrary == null) {
      MegaCollection mcLibrairies = root.getCollection(Constants.MC_LIBRARY);
      final Object bdnaLibraryId = root.currentEnvironment().toolkit().getIDFromString(Constants.MG_ITPEDIA_LIBRARY);
      this.moITPEDIALibrary = mcLibrairies.get(bdnaLibraryId);
      if (!this.moITPEDIALibrary.exists()) {
        this.moITPEDIALibrary = mcLibrairies.create(bdnaLibraryId);
        this.moITPEDIALibrary.setProp("~210000000900[Name]", "IT-Pedia");
      }
    }
    return this.moITPEDIALibrary;
  }

  private void setMegaProperty(final MegaObject softwareTechnologyToAddOrUpdate, final NormalizedProduct product) {
    softwareTechnologyToAddOrUpdate.setProp(Constants.MA_COMPANY_STANDARD, "A");
    softwareTechnologyToAddOrUpdate.setProp(Constants.MA_CATALOG_ITEM_NAME, product.getCatalogItemName());
    softwareTechnologyToAddOrUpdate.setProp(Constants.MA_DEFAULT_LICENCE_TYPE, product.getDefaultLicenseType());
    softwareTechnologyToAddOrUpdate.setProp(Constants.MA_EDITION, product.getEdition());
    softwareTechnologyToAddOrUpdate.setProp(Constants.MA_ITEMS_PER_PRODUCT, product.getItemsPerProduct());
    softwareTechnologyToAddOrUpdate.setProp(Constants.MA_MGF_PART_NUMBER, product.getmFGPartNo());
    softwareTechnologyToAddOrUpdate.setProp(Constants.MA_OPERATING_SYSTEM, product.getOperatingSystem());
    // softwareTechnologyToAddOrUpdate.setProp(Constants.MA_PART_NUMBER,
    // product.getPartNumber());
    softwareTechnologyToAddOrUpdate.setProp(Constants.MA_VERSION, product.getVersion());
    if (Constants.isValidDate(product.getEndOfSupport())) {
      softwareTechnologyToAddOrUpdate.setProp(Constants.MA_END_OF_SUPPORT,
          Constants.convertToMegaDate(product.getEndOfSupport()), "internal");
    } else if (product.getEndOfSupport() != null) {
      softwareTechnologyToAddOrUpdate.setProp(Constants.MA_ENF_OF_SUPPORT_NOTES, product.getEndOfSupport());
    }
    if (Constants.isValidDate(product.getEndOfExtendedSupport())) {
      softwareTechnologyToAddOrUpdate.setProp(Constants.MA_END_OF_EXTENDED_SUPPORT,
          Constants.convertToMegaDate(product.getEndOfExtendedSupport()), "internal");
    } else if (product.getEndOfExtendedSupport() != null) {
      softwareTechnologyToAddOrUpdate.setProp(Constants.MA_END_OF_EXTENDED_SUPPORT_NOTES,
          product.getEndOfExtendedSupport());
    }

    if (Constants.isValidDate(product.getStartOfLife())) {
      softwareTechnologyToAddOrUpdate.setProp(Constants.MA_START_OF_LIFE,
          Constants.convertToMegaDate(product.getStartOfLife()), "internal");
    } else if (product.getStartOfLife() != null) {
      softwareTechnologyToAddOrUpdate.setProp(Constants.MA_START_OF_LIFE_NOTES, product.getStartOfLife());
    }

    if (Constants.isValidDate(product.getEndOfLife())) {
      softwareTechnologyToAddOrUpdate.setProp(Constants.MA_END_OF_LIFE,
          Constants.convertToMegaDate(product.getEndOfLife()), "internal");
    } else if (product.getEndOfLife() != null) {
      softwareTechnologyToAddOrUpdate.setProp(Constants.MA_END_OF_LIFE_NOTES, product.getEndOfLife());
    }

    if (Constants.isValidDate(product.getPriceDate())) {
      softwareTechnologyToAddOrUpdate.setProp(Constants.MA_PRICE_DATE,
          Constants.convertToMegaDate(product.getPriceDate()), "internal");
    } else if (product.getPriceDate() != null) {
      softwareTechnologyToAddOrUpdate.setProp(Constants.MA_PRICE_DATE_NOTES, product.getPriceDate());
    }

    if (Constants.isValidDate(product.getEndOfSale())) {
      softwareTechnologyToAddOrUpdate.setProp(Constants.MA_END_OF_SALE,
          Constants.convertToMegaDate(product.getEndOfSale()), "internal");
    } else if (product.getEndOfSale() != null) {
      softwareTechnologyToAddOrUpdate.setProp(Constants.MA_END_OF_SALE_NOTES, product.getEndOfSale());
    }

    if (Constants.isValidDate(product.getReleaseDate())) {
      softwareTechnologyToAddOrUpdate.setProp(Constants.MA_RELEASE_DATE,
          Constants.convertToMegaDate(product.getReleaseDate()), "internal");
    } else if (product.getReleaseDate() != null) {
      softwareTechnologyToAddOrUpdate.setProp(Constants.MA_RELEASE_DATE_NOTES, product.getReleaseDate());
    }

  }

  private void updateNotFoundAttribute(final List<NormalizedProduct> products,
      final HashMap<String, MegaObject> mapEracentTechnologies) {
    for (Map.Entry<String, MegaObject> entry : mapEracentTechnologies.entrySet()) {
      String e = entry.getKey();
      NormalizedProduct productInRepository = products.stream().filter(product -> e.equals(product.getId())).findAny()
          .orElse(null);
      if (productInRepository != null) {
        entry.getValue().setProp(Constants.MA_NOT_FOUND, false, "internal");

      } else {
        entry.getValue().setProp(Constants.MA_NOT_FOUND, true, "internal");
        this.numberofNotfoundTech++;
      }
    }
  }

}
