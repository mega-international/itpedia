package com.mega.itpedia.model;

import org.codehaus.jackson.annotate.JsonProperty;
import java.util.List;

public class PublicModels {

    @JsonProperty("@odata.nextLink")
    String nextLink;
    @JsonProperty("value")
    List<Model> models;
    public String getNextLink() {
        return nextLink;
    }
    public void setNextLink(String nextLink) {
        this.nextLink = nextLink;
    }
    public List<Model> getModels() {
        return models;
    }
    public void setModels(List<Model> models) {
        this.models = models;
    }
    
}
