package com.mega.itpedia.connexion;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.Proxy;
import java.net.ProxySelector;
import java.net.URI;
import java.net.URISyntaxException;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.List;

import org.json.JSONException;
import org.json.JSONObject;

import com.mega.modeling.api.MegaCurrentEnvironment;
import com.mega.modeling.api.MegaRoot;

public class Token {

	// Private Parameters
	private MegaRoot mgRoot;
	private String urlParameters = "";
	private String url_token = "";

	// Webservice Endpoints
	public static String sEndPoint_Token = "token";
	private String urlParametersFormat = "username=%USER%&password=%PWD%&grant_type=password";

	// Connection Parameters
	private int responseCode;
	private String itPediaURL = "";
	private String access_token;

	// API EndPoints
	public String getItPediaURL() {
		if (this.itPediaURL.endsWith("/")) {
			return this.itPediaURL;
		} else {
			return this.itPediaURL.concat("/");
		}
	}

	public String getAccess_token() {
		return this.access_token;
	}

	public int getResponseCode() {
		return this.responseCode;
	}

	public void getConnectionParameters() {
		MegaCurrentEnvironment ce = this.mgRoot.currentEnvironment();
		this.itPediaURL = ce.getUserOption("IT-Pedia", "ITPEDIABASEURL");
		String itPediaUser = ce.getUserOption("IT-Pedia", "ITPEDIAUser");
		String itPediaPass = ce.getUserOption("IT-Pedia", "ITPEDIAKey");
		this.urlParameters = this.urlParametersFormat.replace("%USER%", itPediaUser).replace("%PWD%", itPediaPass);
		this.url_token = this.getItPediaURL().concat(Token.sEndPoint_Token);

	}

	public Token(final MegaRoot root) throws Exception {
		// System.setProperty("java.net.useSystemProxies", "true");
		this.mgRoot = root;
		this.getConnectionParameters();
		this.calculateToken();
	}

	private void calculateToken() throws URISyntaxException {
		OutputStream os = null;
		BufferedReader in = null;
		try {

			byte[] postData = this.urlParameters.getBytes(StandardCharsets.UTF_8);
			int postDataLength = postData.length;
			URL url = new URL(this.url_token);
			HttpURLConnection conn;
			Proxy valideProxy = this.getValideProxy(url);
			if (valideProxy == null) {
				conn = (HttpURLConnection) url.openConnection();
			} else {
				conn = (HttpURLConnection) url.openConnection(valideProxy);
			}
			conn.setDoOutput(true);
			conn.setInstanceFollowRedirects(false);
			conn.setRequestMethod("POST");
			conn.setRequestProperty("Content-Type", "application/x-www-form-urlencoded");
			conn.setRequestProperty("charset", "utf-8");
			conn.setRequestProperty("Content-Length", Integer.toString(postDataLength));
			os = conn.getOutputStream();
			os.write(postData);
			this.responseCode = conn.getResponseCode();
			if ((this.responseCode >= 200) && (this.responseCode < 300)) {
				in = new BufferedReader(new InputStreamReader(conn.getInputStream(), "UTF-8"));
				StringBuffer buf = new StringBuffer();
				String line;
				while ((line = in.readLine()) != null) {
					buf.append(line);
				}
				JSONObject json = new JSONObject(buf.toString());
				this.access_token = json.getString("access_token");

			}
		} catch (MalformedURLException e) {
			this.responseCode = 500;
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
			this.responseCode = 500;
		} catch (JSONException e) {

			e.printStackTrace();
			this.responseCode = 500;
		} finally {
			try {
				if (os != null) {
					os.close();
				}
				if (in != null) {
					in.close();
				}
			} catch (Exception e) {
				this.responseCode = 500;
			}
		}
	}

	public Proxy getValideProxy(final URL url) throws URISyntaxException, IOException {
		Proxy valideProxy = null;
		List<Proxy> listproxy = ProxySelector.getDefault().select(new URI(this.url_token));
		if (!listproxy.isEmpty()) {
			for (Proxy p : listproxy) {
				HttpURLConnection test = (HttpURLConnection) url.openConnection(p);
				if (test.getResponseCode() == 200) {
					valideProxy = p;
					break;
				}
			}
		}
		return valideProxy;
	}

	public String doGet(final String sUrl) {

		BufferedReader in = null;
		String strResult = "";
		try {
			URL url = new URL(sUrl);
			HttpURLConnection conn;
			if (this.getValideProxy(url) == null) {
				conn = (HttpURLConnection) url.openConnection();
			} else {
				conn = (HttpURLConnection) url.openConnection(this.getValideProxy(url));
			}

			conn.setRequestProperty("Authorization", "Bearer " + this.getAccess_token());
			conn.setRequestProperty("Content-Type", "application/json");
			conn.setRequestMethod("GET");
			conn.setUseCaches(false);
			conn.setDoInput(true);
			conn.setDoOutput(false);

			if (conn.getResponseCode() == 200) {
				in = new BufferedReader(new InputStreamReader(conn.getInputStream(), "UTF-8"));
				StringBuilder buf = new StringBuilder();
				String line;
				while ((line = in.readLine()) != null) {
					buf.append(line + "\n");
				}
				strResult = buf.toString();
			}
		} catch (Exception e) {

		} finally {
			try {
				if (in != null) {
					in.close();

				}
			} catch (Exception e) {

			}
		}

		return strResult;
	}

	public String doPost(final String sUrl) {
		String strResult = "";
		BufferedReader in = null;
		try {
			URL url = new URL(sUrl);
			HttpURLConnection conn;
			if (this.getValideProxy(url) == null) {
				conn = (HttpURLConnection) url.openConnection();
			} else {
				conn = (HttpURLConnection) url.openConnection(this.getValideProxy(url));
			}
			conn.setRequestMethod("POST");
			conn.setDoOutput(true);
			conn.setRequestProperty("Authorization", "Bearer " + this.getAccess_token());

			String post = "";
			byte[] out = post.getBytes(StandardCharsets.UTF_8);
			int length = out.length;
			conn.addRequestProperty("Content-Length", "" + length);
			conn.setFixedLengthStreamingMode(length);
			conn.setRequestProperty("Content-Type", "application/x-www-form-urlencoded; charset=UTF-8");
			conn.setUseCaches(false);
			conn.connect();
			try (OutputStream os = conn.getOutputStream()) {
				os.write(out);
			}

			if (conn.getResponseCode() == 200) {
				in = new BufferedReader(new InputStreamReader(conn.getInputStream(), "UTF-8"));
				StringBuilder buf = new StringBuilder();
				String line;
				while ((line = in.readLine()) != null) {
					buf.append(line + "\n");
				}
				strResult = buf.toString();
			}

		} catch (Exception e) {

		} finally {
			try {
				if (in != null)
					in.close();
			} catch (Exception e) {

			}
		}

		return strResult;
	}

	public MegaRoot getMgRoot() {
		return this.mgRoot;
	}
}
