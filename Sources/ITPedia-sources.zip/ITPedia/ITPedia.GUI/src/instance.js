export default class {
    constructor(containerId, options, customControls, callback, scope)
    {

    }
    onCurrentObjectChange(mcId, objId) {
    }
}
