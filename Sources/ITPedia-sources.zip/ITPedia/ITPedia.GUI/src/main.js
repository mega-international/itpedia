let catalog = window.hopexaddons.getCatalog();
import builderFactory from "./factory";

catalog.register("ItpediaBuilder", builderFactory);
