import { platform } from "os";
import Instance from "./instance";


import I18n from "./utils/i18n/I18n";
import I18nLanguage from "./utils/i18n/Language";

// Hopex Grid Filter Bar
class Factory {
    getName() {
        return "ItpadiaBuilder";
    }

    getVersion() {
        return "v2.0.0.0";
    }

    async initITPedia(params) {
        var me = this;
        me.readParams(params);
        me.bundle = await I18n.getBundle();
        me.options = {
            bundle: me.bundle,
            guiLanguage: me.guiLanguage
        };
        if (me.parameterization) me.options.parameterization = me.parameterization;
    }

    readParams(params) {
        let me = this;
        let guiLanguage = params.language.gui;
        if (guiLanguage) {
            I18n.setCurrentLang(new I18nLanguage(guiLanguage.iso, guiLanguage.mega, guiLanguage.idabs));
            me.guiLanguage = guiLanguage.iso;
        }
        if (params.parameterization) me.parameterization = params.parameterization;
    }

    async instantiate(containerId, params, callback, scope) {

        var me = this;
        if (!me.initialized) {
            await me.initITPedia(params);
        }

        var manufacturerURL = "object.aspx?data=generationType-standard|generator-9D42CE23615D5760";
        var productUrl = "object.aspx?data=generationType-standard|generator-A4A78CE2614C1F00";
        var modelUrl = "object.aspx?data=generationType-standard|generator-3FF2412C616542F4";
        var ImportProducturl = "object.aspx?data=generationType-standard|generator-5075858B6169463F";


        var selected, selectedcount;
        var selectedManufacturer, selectedProduct, typedVersion, typedPlatform;


        // Grid Buttons
        var importButton = Ext.create('Ext.Button', {
            text: me.bundle.get('Import'),
            tooltip: me.bundle.get('Import Products'),
            disabled: true,
            bodyPadding: 20,
            style: 'float:right;',
            handler: function (t) {
                var grid = t.up('gridpanel');
                selected = grid.getSelection();
                var panelvalues, SelectionCount;
                var selection = [];
                if (selected.length) {
                    selected.map(item => {
                        panelvalues = parseInt(item.data.cModel_ID);
                        selection.push(panelvalues);
                    });
                }
                var queryParams = {
                    modelList: selection.toString(),
                    bolimported: false
                };

                SelectionCount = selection.length;
                var messagebox = Ext.MessageBox.show({
                    title: me.bundle.get('Please wait'),
                    msg: me.bundle.get('Importing Products...'),
                    progressText: me.bundle.get('Processing...'),
                    wait: true,
                    width: 300,
                    progress: true,
                    closable: false
                });

                var test = Ext.Ajax.request({
                    url: ImportProducturl,
                    method: 'POST',
                    params: {
                        "userdata": Ext.encode(queryParams)

                    },
                    success: function (response, opts) {
                        messagebox.hide();
                        Ext.Msg.alert(me.bundle.get('Status'), me.bundle.get('Products Imported succesfully'));
                    },
                    failure: function (response, opts) {
                        messagebox.hide();
                        Ext.Msg.alert(me.bundle.get('Status'), me.bundle.get('Products Import failed'));
                    },
                    scope: this
                });
            }
        });

        var clearButton = Ext.create('Ext.Button', {
            text: me.bundle.get('Clear'),
            tooltip: me.bundle.get('Clear All'),
            handler: function (t) {
                var grid = t.up('gridpanel');
                productCombo.clearValue();
                manufacturerCombo.clearValue();
                productCombo.setDisabled(true);
                versionCombo.clearValue();
                platformCombo.clearValue();
                versionCombo.setDisabled(true);
                platformCombo.setDisabled(true);
                grid.resetAndHide();
            }
        });

        // Models Grid Store
        var listStore = Ext.create('Ext.data.Store', {
            storeId: 'Itpediastore',
            autoDestroy: true,
            bodyPadding: 20,
            autoLoad: false,
            autoSync: false,
            fields: ['modelName', 'mfgName', 'prodName', 'version', 'platform', 'cModel_ID'],
            sorters: [
                {
                    property: 'modelName',
                    direction: 'ASC'
                }
            ],
            proxy: {
                type: 'ajax',
                url: modelUrl,
                actionMethods: {
                    create: 'POST',
                    read: 'POST',
                    update: 'POST',
                    destroy: 'POST'
                },
                enablePaging: false,
            },
            reader: {
                type: 'json',
                rootProperty: 'occ'
            },
            listeners: {
                load: function (store, records, successful, operation, eOpts) {
                    store.updateDisplayed(store);
                },
                filterchange(store, filters, eOpts) {
                    store.updateDisplayed(store);
                }
            },
            updateDisplayed: function (store) {
                if (countRecord != null) {
                    countRecord.setValue(me.bundle.get('Displaying') + ':  ' + store.getCount());
                    modelsGrid.getSelectionModel().deselectAll();
                    if (countSelected != null) {
                        countSelected.hide();
                    }   
                }

            }
        });

        // Bbars
        var countRecord = Ext.create('Ext.form.field.Display', { 
            name: 'count_record'
        });

        var countSelected = Ext.create('Ext.form.field.Display', {
            name: 'count_selected'
        });

        // Grid Filter Plugin
        /*
        var filterPlugin = Ext.create('mega.model.util.list.filterBar.FilterBar', {
            updateToolbarVisibility: Ext.emptyFn,
            renderHidden: true,
            ptype: 'plugin.filterBar',
            pluginId: 'itpediaFilterBar',
            showTool: false,
            dock: 'top'
        });
        */

        // Models Grid Store
        var modelsGrid = Ext.create('Ext.grid.Panel', {
            // plugins: [
            //     //filterPlugin
            // ],
            store: listStore,
            SelectionMemory: 'Enabled',
            persistSelection: true,
            flex: 1,
            maxHeight: 530,
            columns: [
                { text: me.bundle.get('Model Name'), dataIndex: 'modelName', flex: 4, filter: { type: 'string' } },
                { text: me.bundle.get('Vendor'), dataIndex: 'mfgName', flex: 2, filter: { type: 'string' } },
                { text: me.bundle.get('Product'), dataIndex: 'prodName', flex: 2, filter: { type: 'string' } },
                { text: me.bundle.get('Version'), dataIndex: 'version', flex: 1, filter: { type: 'string' } },
                { text: me.bundle.get('Model Id'), dataIndex: 'cModel_ID', hidden: true, hideable: false, filter: { type: 'string' } },
                { text: me.bundle.get('Platform'), dataIndex: 'platform', flex: 1, filter: { type: 'string' } }
            ],

            selModel: {
                checkOnly: false,
                injectCheckbox: 'first',
                mode: 'SIMPLE',
                selType: 'checkboxmodel',
                pruneRemoved: false
            },

            viewConfig: {
                stripeRows: true,
                deferEmptyText: false,
            },

            listeners: {
                selectionchange:function(grid,selected,eOpts){
                    selectedcount = grid.getSelection().length;
                    if (selectedcount == 0) {
                        importButton.setDisabled(true);
                        countSelected.hide();
                    } else {
                        if (countSelected != null) {
                            countSelected.setValue(me.bundle.get('Selected') + ': ' + selectedcount);
                            countSelected.show();
                        }
                        importButton.show();
                        importButton.setDisabled(false);
                    }
                }
                
            },
            tbar: [
                importButton,
                '-',
                clearButton
            ],
            bbar: [
                countSelected,
                '->',
                countRecord
            ],
            resetAndHide: function () {
                selectedcount = 0;
                this.getStore().removeAll();
                this.getStore().sync();
                this.hide();
            },
            resetOnly: function () {
                this.getStore().removeAll();
                this.getStore().sync();
            }
        });


        // Platform Store
        var platformStore = new Ext.data.Store({
            autoDestroy: true,
            fields: [
                'platform_ID',
                'platform'
            ],
            sorters: [
                {
                    property: 'platform',
                    direction: 'ASC'
                }
            ]

        });

        // Platform Combo
        var platformCombo = Ext.create('Ext.form.ComboBox', {
            fieldLabel: me.bundle.get('Platform'),
            queryMode: 'local',
            disabled: true,
            displayField: 'platform',
            valueField: 'platform',
            margin: '0 10px 0 0',
            labelAlign: 'top',
            flex: 1,
            lastQuery: '',
            store: platformStore,
            listeners: {
                'beforequery': function (qe) {
                    if (platformCombo.getStore().data.length == 0) {
                        this.setStore(modelsGrid.getStore().collect('platform'));
                    }
                    return true;
                },
                change: function (field, newValue, oldValue) {
                    if (newValue) {
                        typedPlatform = newValue;
                        modelsGrid.getStore().filter({
                            property: 'platform',
                            value: newValue,
                            exactMatch: false,
                            caseSensitive: false
                        })
                    } else {
                        modelsGrid.getStore().clearFilter();
                        if (versionCombo.getValue()) {
                            if (versionCombo.getValue().length != 0) {
                                modelsGrid.getStore().filter({
                                    property: 'version',
                                    value: typedVersion,
                                    exactMatch: false,
                                    caseSensitive: false
                                })
                            }
                        }
                    }
                },
                select: function (combo, records, eOpts) {
                    modelsGrid.getStore().filter({
                        property: 'platform',
                        value: records.data.field1,
                        exactMatch: true,
                        caseSensitive: false
                    })
                }
            }
        });


        // Version Store
        var versionStore = new Ext.data.Store({
            autoDestroy: true,
            fields: [
                'version'
            ],
            sorters: [
                {
                    property: 'version',
                    direction: 'ASC'
                }
            ]
        });

        // Version Combo
        var versionCombo = Ext.create('Ext.form.ComboBox', {
            fieldLabel: me.bundle.get('Version'),
            queryMode: 'local',
            disabled: true,
            displayField: 'version',
            valueField: 'version',
            margin: '0 10px 0 0',
            labelAlign: 'top',
            flex: 1,
            store: versionStore,
           
            listeners: {
                'beforequery': function (qe) {
                    if (versionCombo.getStore().data.length == 0) {
                        this.setStore(modelsGrid.getStore().collect('version'));
                    }
                    return true;
                },
                change: function (field, newValue, oldValue) {
                    if (newValue) {
                        typedVersion = newValue;
                        modelsGrid.getStore().filter({
                            property: 'version',
                            value: newValue,
                            exactMatch: false,
                            caseSensitive: false
                        })

                    } else {
                        modelsGrid.getStore().clearFilter();
                        if (platformCombo.getValue()) {
                            if (platformCombo.getValue().length != 0) {
                                modelsGrid.getStore().filter({
                                    property: 'platform',
                                    value: typedPlatform,
                                    exactMatch: false,
                                    caseSensitive: false
                                })
                            }
                        }
                    }
                },
                select: function (combo, records, eOpts) {
                    var selectedVersion = records.data.field1;
                    modelsGrid.getStore().filter({
                        property: 'version',
                        value: records.data.field1,
                        exactMatch: true,
                        caseSensitive: false
                    })
                }
            }
        });



        // Product Store
        var productStore = new Ext.data.Store({
            autoDestroy: true,
            proxy: {
                type: 'ajax',
                url: productUrl,
                actionMethods: {
                    create: 'POST',
                    read: 'POST',
                    update: 'POST',
                    destroy: 'POST'
                },
            },
            reader: {
                type: 'json',
                rootProperty: 'occ'
            },
            fields: [
                'cProduct_ID',
                'prodName'
            ],
            sorters: [
                {
                    property: 'prodName',
                    direction: 'ASC'
                }
            ]
        });

        // Product Filter
        var productFilter = new Ext.util.Filter({
            filterFn: function (item) {
                var searchValue = productCombo.getValue();
                if (searchValue === null) {
                    searchValue = "";
                } else {
                    searchValue = searchValue.toLowerCase();
                }
                return item.get('prodName').toLowerCase().indexOf(searchValue) == 0;
            }
        });

        // Product Combo
        var productCombo = Ext.create('Ext.form.ComboBox', {
            fieldLabel: me.bundle.get('Product'),
            queryMode: 'remote',
            allowBlank: false,
            disabled: true,
            displayField: 'prodName',
            valueField: 'prodName',
            minChars: 2,
            typeAhead: true,
            emptyText: me.bundle.get('Choose a product'),
            lastQuery: '',
            margin: '0 10px 0 0',
            labelAlign: 'top',
            flex: 1,
            store: productStore,
            listeners: {
                'beforequery': function (qe) {
                    var me = this;
                    var queryParams = {
                        query: encodeURI(qe.query),
                        manufacturer: selectedManufacturer,
                    };
                    me.getStore().getProxy().setExtraParam("userdata", Ext.encode(queryParams));
                    productStore.load();
                    productStore.filter(productFilter);
                    if (manufacturerStore.data.length == 0) {
                        modelsGrid.resetAndHide();
                        versionCombo.clearValue();
                        platformCombo.clearValue();
                        productCombo.setDisabled(true);
                        versionCombo.setDisabled(true);
                        platformCombo.setDisabled(true);
                    }
                    return true;
                },
                change: function (field, newValue, oldValue) {
                    if (newValue) {
                        if (newValue.length == 0) {
                            platformCombo.clearValue();
                            platformCombo.setDisabled(true);
                            versionCombo.clearValue();
                            versionCombo.setDisabled(true);
                            modelsGrid.resetAndHide();
                        }
                    } else {
                        platformCombo.clearValue();
                        platformCombo.setDisabled(true);
                        versionCombo.clearValue();
                        versionCombo.setDisabled(true);
                        modelsGrid.resetAndHide();
                    }
                },
                select: function (combo, records, eOpts) {
                    selectedProduct = records.data.cProduct_ID;
                    var queryParams = {
                        query: selectedManufacturer, // la query qui est dans la combo ; si c’est une chaine vide, on charge toute la liste
                        productID: selectedProduct,
                        limit: '9'
                    };
                    modelsGrid.resetOnly();
                    modelsGrid.getStore().load({
                        params: {
                            start: 0,
                            limit: 50
                        }
                    }).getProxy().setExtraParam("userdata", Ext.encode(queryParams));
                    platformCombo.clearValue();
                    platformCombo.getStore().removeAll();
                    platformCombo.setDisabled(false);
                    versionCombo.clearValue();
                    versionCombo.getStore().removeAll();
                    versionCombo.setDisabled(false);
                    modelsGrid.getStore().clearFilter();
                    modelsGrid.show();
                    importButton.show();

                }
            }
        });


        // Manufacturer Store
        var manufacturerStore = new Ext.data.Store({
            autoDestroy: true,
            proxy: {
                type: 'ajax',
                url: manufacturerURL,
                actionMethods: {
                    create: 'POST',
                    read: 'POST',
                    update: 'POST',
                    destroy: 'POST'
                },
            },
            reader: {
                type: 'json',
                rootProperty: 'occ'
            },
            fields: [
                'cMfg_ID',
                'mfgName'
            ],
            sorters: [
                {
                    property: 'mfgName',
                    direction: 'ASC'
                }
            ]
        });

        // Manufacturer Filter
        var manufacturerFilter = new Ext.util.Filter({
            filterFn: function (item) {
                var searchValue = manufacturerCombo.getValue();
                if (searchValue === null) {
                    searchValue = "";
                } else {
                    searchValue = searchValue.toLowerCase();
                }
                return item.get('mfgName').toLowerCase().indexOf(searchValue) == 0;
            }
        });

        // Manufacturer Combo
        var manufacturerCombo = Ext.create('Ext.form.ComboBox', {
            fieldLabel: me.bundle.get('Vendor'),
            queryMode: 'remote',
            displayField: 'mfgName',
            valueField: 'mfgName',
            minChars: 2,
            typeAhead: true,
            emptyText: me.bundle.get('Type a Vendor'),
            lastQuery: '',
            margin: '0 10px 0 0',
            labelAlign: 'top',
            flex: 1,
            store: manufacturerStore,
            listeners: {
                'beforequery': function (qe) {
                    var me = this;
                    if (qe.query.length == 0) {
                        productCombo.clearValue();
                        productCombo.setDisabled(true);
                        modelsGrid.resetAndHide();
                    }

                    var queryParams = {
                        query: encodeURI(qe.query)
                    };
                    me.getStore().getProxy().setExtraParam("userdata", Ext.encode(queryParams));
                    manufacturerStore.load();
                    manufacturerStore.filter(manufacturerFilter);
                    if (manufacturerStore.data.length == 0) {
                        modelsGrid.resetAndHide();
                        productCombo.clearValue();
                        versionCombo.clearValue();
                        platformCombo.clearValue();
                        productCombo.setDisabled(true);
                        versionCombo.setDisabled(true);
                        platformCombo.setDisabled(true);
                    }
                    return true;
                },
                change: function (field, newValue, oldValue) {
                    if (newValue) {
                        if (newValue.length == 0) {
                            productCombo.clearValue();
                            productCombo.setDisabled(true);
                            platformCombo.clearValue();
                            platformCombo.setDisabled(true);
                            versionCombo.clearValue();
                            versionCombo.setDisabled(true);
                            modelsGrid.resetAndHide();
                        }
                    } else {
                        productCombo.clearValue();
                        productCombo.setDisabled(true);
                        platformCombo.clearValue();
                        platformCombo.setDisabled(true);
                        versionCombo.clearValue();
                        versionCombo.setDisabled(true);
                        modelsGrid.resetAndHide();
                    }
                },
                select: function (combo, records, eOpts) {
                    modelsGrid.resetAndHide();
                    importButton.hide();
                    selectedManufacturer = records.data.cMfg_ID;
                    productCombo.setDisabled(false);
                    productCombo.clearValue();
                    var queryParams = {
                        query: "", // la query qui est dans la combo ; si c’est une chaine vide, on charge toute la liste
                        manufacturer: selectedManufacturer
                    };
                    productCombo.getStore().getProxy().setExtraParam("userdata", Ext.encode(queryParams));
                    productCombo.getStore().load({ params: { start: 0, limit: 4 } });
                }
            }
        });

        // Top Panel: panel Containing Filtering Comboboxes
        var topPanel = Ext.create('Ext.form.Panel', {
            title: me.bundle.get("IT-Pedia"),
            bodyPadding: 20,
            layout: {
                type: 'hbox',
                align: 'stretch'
            },
            items: [
                manufacturerCombo,
                productCombo,
                versionCombo,
                platformCombo
            ]
        });

        // Main Container
        var mainContainer = Ext.create('Ext.container.Container', {
            renderTo: containerId,
            
            layout: {
                type: 'vbox',
                align: 'stretch'
            },
            items: [
                topPanel,
                modelsGrid
            ]
        });
        importButton.setHidden(true);
        modelsGrid.setHidden(true);
        Ext.GlobalEvents.on('resize', function(w, h) { 
            mainContainer.setHeight(h-50);
            mainContainer.setWidth(w);
            
        });

        return new Instance(containerId, "", params, callback, scope)
    }
}
let factory = new Factory();
export default factory;



