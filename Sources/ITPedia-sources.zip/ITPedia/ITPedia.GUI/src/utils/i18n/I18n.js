
import Languages from "./Language.js";
import {Bundle} from "./Bundle.js";

class I18n {
  constructor() {
    this._prefPath_HAS   = "/hopex/_customs/module/hopex.itpedia/scripts/resources/";
    this._prefPath_NoHAS = "./addons/resources/itpedia/";
    this._sufPath = "_traductions.js";
    this.DEFAULT_LANG = [
        new Languages('en', 'us', '00(6wlHmk400'),
        new Languages('fr', 'fr', 'B0SNPuLckCQ3')
      ];
  }

  // syncLoad
  async syncLoad(url){
    let langHeader = new Headers({
      "Content-Type":"application/javascript",
      "X-Custom-Header": "ProcessThisImmediately",
    });
    const params = {
      method:"GET",
      headers:langHeader,
      mode:'cors',
      cache:'default'
    };
    
    let response = await fetch(url,params);
    let jsonResponse = await response.json();
    return jsonResponse;
  }

  // setCurrentLang
  setCurrentLang(oLang){
    if (this._currentLang) {
      if (this._currentLang.iabs64 != oLang.iabs64) {
          console.warn('I18n: Locale cannot be set more than once')
      }
      return;
    }
    this._currentLang = oLang;
  }

  // getBundle
  async getBundle(){
    if (this.bundle) return this.bundle;
    //var prefPath=globals && globals.runInHAS ? this._prefPath_HAS:this._prefPath_NoHAS;
    var prefPath=this._prefPath_NoHAS;
    var url = prefPath + this._currentLang.megaCode + this._sufPath;
    var res = await this.syncLoad(url);
    if (!res) {
        var iDefLang;
        for (iDefLang = 0; !res && iDefLang < this.DEFAULT_LANG.length; iDefLang++) {
            url = prefPath + this.DEFAULT_LANG[iDefLang].megaCode + this._sufPath;
            res = await this.syncLoad(url);
        }
        var szDefault = '". Bundle will returns keys.';
        if (res) szDefault = '". Using "' + this.DEFAULT_LANG[iDefLang - 1].megaCode + '".';
        console.warn('I18n: package not translated in "' + this._currentLang.megaCode + szDefault);
    }
    this.bundle = new Bundle(res);
    return this.bundle;
  }
}
export default new I18n();
