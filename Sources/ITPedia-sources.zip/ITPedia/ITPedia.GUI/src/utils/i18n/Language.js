export default class{
  constructor(isoCode, megaCode, idabs64){
    this.isoCode  = isoCode;
    this.megaCode = megaCode;
    this.idabs64  = idabs64;
  }
}
