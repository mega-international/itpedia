
class Bundle {
  constructor(items) {
    this._items = items;
    if (!items) {
        this.get = this._emptyGet;
    }
  }

  _emptyGet(szKey) {
    return szKey;
  }

  get(szKey){
    const value = this._items[szKey];
    if (value) {
        return value;
    } else {
        console.warn('Package  missing ressource "' + szKey + '"');
        return szKey;
    }
  }

  getKeys(){
    return Object.keys(this._items);
  }
}
export {Bundle}
